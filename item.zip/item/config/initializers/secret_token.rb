# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BestBay::Application.config.secret_token = 'd9cc292f96c90b319ed9cfd7459a074b1a2adcb3777d5b081b9ee96d5dcdc14d0a7bd8523eb54cd936f1454cac3ad622918525b234747ba5255059f091fc29e9'
