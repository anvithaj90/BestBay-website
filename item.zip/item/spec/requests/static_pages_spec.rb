require 'spec_helper'

describe "StaticPages" do
  describe "Landing Page" do
    it "should have LOGO" do
      visit '/static_pages/home'
      page.should have_content("Mobitro")
    end
  end
end
