require 'spec_helper'

describe "static_pages/career.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
