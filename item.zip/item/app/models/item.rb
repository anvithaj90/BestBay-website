class Item < ActiveRecord::Base
  attr_accessible :category_id, :general_description, :name, :pic_path, :price, :quality, :seller_id
end
