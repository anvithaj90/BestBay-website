class StaticPagesController < ApplicationController
  def home
  end

  def contact
  end

  def career
  end

  def about
  end
end
