module StaticPagesHelper
end
